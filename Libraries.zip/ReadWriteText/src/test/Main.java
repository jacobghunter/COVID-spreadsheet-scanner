package test;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Array;
import java.util.Scanner;
import java.util.ArrayList;

/**
 *
 * @author Jacob Hunter
 */
//kiwi = array
//createdFile = file creator
//document = file reader
//writer = file writer
public class Main {

    public static void main(String[] args) throws FileNotFoundException, IOException {

        final String path = "C:\\School\\NetBeansProjects\\ReadWriteText\\src\\text file";
        File document = new File(path + "\\IB Comp Sci Program OHS Athletics Health Screening V1a (Responses) - Form Responses 1.csv");

        System.out.println("Do which thing:\n0 - Print all entries\n1 - Copy contents to file\n2 - Exit");
//        File createdFile = new File("C:\\document.txt");
//        FileWriter writer = new FileWriter(createdFile);

        ArrayList<String> scannedStuff = new ArrayList<String>();

        Scanner fileScanner = new Scanner(document).useDelimiter(",|\n");
        Scanner arrayListScanner = new Scanner(System.in).useDelimiter(",");

        String info1 = "";

        Scanner inputScanner = new Scanner(System.in);
        int scannedInput = inputScanner.nextInt();

//        ArrayList<String> arrayList = new ArrayList<String>();
        String athName = "Jane";

//        if(scannedOutput.contains(athName)){
//                System.out.println(athName);
//        }
        switch (scannedInput) {
            case 0:
//                while (fileScanner.hasNextLine() == true) {
//                String scannedOutput = fileScanner.nextLine();
//                    if (scannedOutput.contains(athName)) {
//                        System.out.println(fileScanner.next());
//                        break;
//                    }
//                }
//                fileScanner.close();

                while (fileScanner.hasNextLine()) { //while there is a next line in the document
                    scannedStuff.add(fileScanner.nextLine()); //add the next scanned line into the arraylist
//                    System.out.println(scannedStuff);//print the arraylist (for testing purposes im printing but it will be put in an object later)
//                    System.out.println(scannedStuff.stream().map(i -> i.toString()).collect(Collectors.joining(",")));
                    System.out.println(scannedStuff.toString().replace("[", "").replace("]", ""));
                    String scannedArrayList = arrayListScanner.next();
                    if (scannedArrayList.contains(athName)) {
                        System.out.println(scannedStuff.toString().replace("[", "").replace("]", ""));

                    }
                    scannedStuff.clear(); //clear the arraylist
                    break;
                }
                fileScanner.close();
                break;

            case 1://the second attempt at a working thing that does the exact same thing as the first one but different
                while (fileScanner.hasNext()) { //while there is a next line in the document
                    for (int i = 0; i < 9; i++) { //counts up to 9
                        scannedStuff.add(fileScanner.next()); //adds the next scanned field into the arraylist
                    }
                    int i = 0; //resets counter
                    System.out.println(scannedStuff);//print the arraylist (for testing purposes im printing but it will be put in an object later)
                    scannedStuff.clear(); //clears arraylist after printing
                }

//                createdFile.createNewFile();
//
//                writer.write(scannedOutput);
//                writer.close();
//                System.out.println("Successfully wrote to the file.");
                break;

            case 2:
//                scannedStuff.add("2/10/2021 16:11:36,gmail2@gmail.com,2/10/2021,Doe,Jane,Boy's Volleyball,No,Yes,No");
//                System.out.println(scannedStuff.toString().replace("[", "").replace("]", ""));
//                String scannedArrayList = arrayListScanner.nextLine();
//                if (scannedArrayList.contains(athName)) {
//                    System.out.println(scannedStuff.toString().replace("[", "").replace("]", ""));
//                    scannedStuff.clear();
//                } else {
//                    scannedStuff.clear();
//                }

                String[] urmom = {"blah", "blah", "blah"};
                for (int x = 0; x < 3; x++) {
                    int w = 3;
                    if (w == 3) {
                        Array.set(urmom, x, "notblah");
                    }
                    System.out.println(urmom[x]);
                }

                break;
            case 3:
                while (fileScanner.hasNextLine()) {
                    String scannedLine = fileScanner.nextLine();
                    if (scannedLine.contains(athName)) {
                        info1 = scannedLine;
                        String[] data = info1.split(",");
                        for (String i : data) {
                            System.out.println(i);
                        }
                    }
                }
                break;
            case 4:
//
            case 6:
                ArrayList<Integer> arrayList = new ArrayList<Integer>();
                arrayList.add(69);
                arrayList.add(49);
                arrayList.add(3);
                arrayList.add(19);
                arrayList.add(8);
                for (int i = 0; i < arrayList.size() - 1; i++) {
                    for (int j = 0; j < arrayList.size() - i - 1; j++) {
                        if (arrayList.get(j) > arrayList.get(j + 1)) {
                            // swap arr[j+1] and arr[j] 
                            int temp = arrayList.get(j);
                            int temp2 = arrayList.get(j + 1);
                            arrayList.set(j, temp2); 
                            arrayList.set(j+1, temp); 
                        }
                    }
                }
                for (int i = 0; i < 5; i++) {
                    System.out.println(arrayList.get(i));
                }
        }

    }
}
